<?php
class Validator {
    public function validateProduct($product) {
        $errors = [];

        if (empty($product->name)) {
            $errors[] = "Product name is required.";
        }

        if (empty($product->barcode)) {
            $errors[] = "Barcode is required.";
        }

        if (!is_numeric($product->quantity) || $product->quantity < 0) {
            $errors[] = "Quantity must be a positive number.";
        }

        return $errors;
    }

    public function validateCustomer($customer) {
        $errors = [];
    
        if (empty($customer->name)) {
            $errors[] = "Customer name is required.";
        }
    
        if (empty($customer->email) || !filter_var($customer->email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "A valid email is required.";
        }
    
        if (empty($customer->phone) || !preg_match('/^\+?[0-9]{10,15}$/', $customer->phone)) {
            $errors[] = "A valid phone number is required.";
        }
    
        if (empty($customer->address)) {
            $errors[] = "Address is required.";
        }
    
        return $errors;
    }
    
}
