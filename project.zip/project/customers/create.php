<?php
require_once '../includes/header.php';
require_once '../config/Database.php';
require_once '../models/Customer.php';
require_once '../utils/Validator.php';

$database = new Database();
$db = $database->getConnection();
$customer = new Customer($db);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Inclure le gestionnaire pour traiter l'ajout
    require_once 'handlers/create-handler.php';
}
?>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Add New Customer</h1>
        <a href="../index.php" class="btn btn-secondary">Back to Customers</a>
    </div>

    <?php include 'partials/form-errors.php'; ?>

    <div class="card">
        <div class="card-body">
            <?php include 'partials/customer-form.php'; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
