<?php
require_once '../includes/header.php';
require_once '../config/Database.php';
require_once '../models/Customer.php';

$database = new Database();
$db = $database->getConnection();
$customer = new Customer($db);

// Vérifier si un ID est passé dans l'URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $customer->id = $_GET['id'];

    // Charger les données du client
    $stmt = $customer->readOne();
    $customerData = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($customerData) {
        // Mapper les données dans l'objet
        $customer->name = $customerData['name'];
        $customer->email = $customerData['email'];
        $customer->phone = $customerData['phone'];
        $customer->address = $customerData['address'];
    } else {
        // Rediriger si l'ID est invalide
        header('Location: index.php?error=Customer not found');
        exit;
    }
} else {
    // Rediriger si aucun ID n'est fourni
    header('Location: index.php?error=No customer ID provided');
    exit;
}
?>

<div class="container">
    <h1>Edit Customer</h1>
    <?php if (!empty($_SESSION['errors'])): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($_SESSION['errors'] as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php unset($_SESSION['errors']); ?>
    <?php endif; ?>
    <form action="handlers/edit-handler.php" method="POST">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($customer->id); ?>">
        <div class="form-group">
            <label for="name">Customer Name</label>
            <input type="text" name="name" id="name" class="form-control" value="<?php echo htmlspecialchars($customer->name); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($customer->email); ?>" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone</label>
            <input type="text" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($customer->phone); ?>" required>
        </div>
        <div class="form-group">
            <label for="address">Address</label>
            <textarea name="address" id="address" class="form-control" rows="3" required><?php echo htmlspecialchars($customer->address); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update Customer</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
