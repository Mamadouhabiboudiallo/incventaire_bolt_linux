<?php
echo "Chemin actuel : " . $_SERVER['REQUEST_URI'];

require_once '../../config/Database.php';
require_once '../../models/Customer.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $database = new Database();
    $db = $database->getConnection();

    $customer = new Customer($db);
    $customer->id = $_POST['id'];

    if ($customer->delete()) {
        header('Location: ../index.php?success=Customer deleted successfully');
    } else {
        // Handle error
        echo "Error deleting customer.";
    }
} else {
    header('Location: ../index.php');
}
exit;
