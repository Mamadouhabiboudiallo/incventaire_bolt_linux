<?php
if (!empty($_POST)) {
    $customer->name = $_POST['name'];
    $customer->email = $_POST['email'];
    $customer->phone = $_POST['phone'];
    $customer->address = $_POST['address'];

    if ($customer->create()) {
        header("Location: ../index.php?success=Customer created successfully");
        exit;
    } else {
        $errors[] = "Failed to create customer.";
    }
}
