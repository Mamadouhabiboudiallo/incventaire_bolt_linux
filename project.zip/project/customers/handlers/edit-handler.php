<?php
require_once '../../config/Database.php';
require_once '../../models/Customer.php';
require_once '../../utils/Validator.php';

$database = new Database();
$db = $database->getConnection();

$customer = new Customer($db);
$validator = new Validator();

$customer->id = $_POST['id'] ?? '';
$customer->name = $_POST['name'] ?? '';
$customer->email = $_POST['email'] ?? '';
$customer->phone = $_POST['phone'] ?? '';
$customer->address = $_POST['address'] ?? '';

$errors = $validator->validateCustomer($customer);

if (empty($errors)) {
    if ($customer->update()) {
        header('Location: ../index.php?success=Customer updated successfully');
        exit;
    } else {
        $errors[] = "Unable to update customer.";
    }
}

// If errors exist, redirect back with errors
session_start();
$_SESSION['errors'] = $errors;
header('Location: ../edit.php?id=' . $customer->id);
exit;
