<?php
// Inclusion de la connexion à la base de données
require_once '../includes/init.php';
require_once '../includes/header.php';

// Initialiser les variables
$searchType = isset($_GET['search_type']) ? $_GET['search_type'] : '';
$searchQuery = isset($_GET['search_query']) ? $_GET['search_query'] : '';

// Vérifier si le formulaire a été soumis avec un terme de recherche
if ($_SERVER["REQUEST_METHOD"] === "GET" && !empty($searchQuery)) {
    // Connexion à la base de données
    $database = new Database();
    $db = $database->getConnection();

    // Si on recherche un produit
    if ($searchType === 'product') {
        $query = "SELECT id, barcode, name, quantity, price FROM products WHERE name LIKE :search_query OR barcode LIKE :search_query";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':search_query', "%$searchQuery%", PDO::PARAM_STR);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Si on recherche un client
    } elseif ($searchType === 'customer') {
        $query = "SELECT id, name,address,phone, email FROM customers WHERE name LIKE :search_query OR email LIKE :search_query";
        $stmt = $db->prepare($query);
        $stmt->bindValue(':search_query', "%$searchQuery%", PDO::PARAM_STR);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } else {
        // Si le type de recherche n'est pas défini ou invalide
        $results = [];
    }
} else {
    $results = [];
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultats de la recherche</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<div class="container">
    <h1>Résultats de la recherche</h1>

    <!-- Afficher les résultats -->
    <?php if (!empty($results)): ?>
        <table class="table">
            <thead>
                <tr>
                    <?php if ($searchType === 'product'): ?>
                        <th>Barcode</th>
                        <th>Nom</th>
                        <th>Quantité</th>
                        <th>Prix</th>
                    <?php elseif ($searchType === 'customer'): ?>
                        <th>Nom</th>
                        <th>Adresser</th>
                        <th>Telephone</th>
                        <th>Email</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $result): ?>
                    <tr>
                        <?php if ($searchType === 'product'): ?>
                            <td><?php echo htmlspecialchars($result['barcode']); ?></td>
                            <td><?php echo htmlspecialchars($result['name']); ?></td>
                            <td><?php echo htmlspecialchars($result['quantity']); ?></td>
                            <td><?php echo htmlspecialchars($result['price']); ?> €</td>
                        <?php elseif ($searchType === 'customer'): ?>
                            <td><?php echo htmlspecialchars($result['name']); ?></td>
                            <td><?php echo htmlspecialchars($result['address']); ?></td>
                            <td><?php echo htmlspecialchars($result['phone']); ?></td>
                            <td><?php echo htmlspecialchars($result['email']); ?></td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucun résultat trouvé pour "<?php echo htmlspecialchars($searchQuery); ?>"</p>
    <?php endif; ?>

    <a href="index.php" class="btn btn-secondary">Retour à la page customers</a>
</div>
<?php require_once '../includes/footer.php'; ?>

</body>
</html>
