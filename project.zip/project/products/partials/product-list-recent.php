
<?php
// Connexion à la base de données
$database = new Database();
$db = $database->getConnection();

// Récupérer les produits récents
$query = "SELECT id, barcode, quantity, name FROM products ORDER BY created_at DESC LIMIT 5";  // Vous pouvez ajuster la limite
$stmt = $db->prepare($query);
$stmt->execute();

// Récupérer les produits
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Inclure la vue partielle pour afficher les produits récents
?>


<?php if (isset($products) && count($products) > 0): ?>
    <?php foreach ($products as $product): ?>
        <tr>
            <td><?php echo htmlspecialchars($product['name']); ?></td>  <!-- Affiche le barcode -->
            <td><?php echo htmlspecialchars($product['quantity']); ?></td>  <!-- Affiche la quantité -->
            <td><a href="products/partials/product-details.php?id=<?php echo htmlspecialchars($product['id']); ?>" class="btn btn-info btn-sm">Details</a></td>
        </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="3" class="text-center">No recent products found.</td>
    </tr>
<?php endif; ?>
