<?php
// Inclusion de la connexion à la base de données et du modèle de données (si nécessaire)
require_once '../../includes/init.php';
require_once '../../includes/header.php';

// Vérifier si l'ID du produit est passé dans l'URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Produit introuvable.";
    exit;
}

// Récupérer l'ID du produit depuis l'URL
$productId = (int)$_GET['id'];  // On s'assure que c'est un entier pour éviter toute injection

// Connexion à la base de données
$database = new Database();
$db = $database->getConnection();

// Préparer la requête pour récupérer les détails du produit
$query = "SELECT id, barcode, quantity, name, created_at FROM products WHERE id = :id LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(':id', $productId, PDO::PARAM_INT);  // Lier l'ID du produit
$stmt->execute();

// Récupérer le produit
$product = $stmt->fetch(PDO::FETCH_ASSOC);

// Vérifier si le produit existe
if (!$product) {
    echo "Produit introuvable.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails du produit</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<div class="container">
    <h1>Détails du produit</h1>

    <!-- Informations du produit -->
    <div class="product-details">
        <table class="table">
            <tr>
                <th>Barcode</th>
                <td><?php echo htmlspecialchars($product['barcode']); ?></td>
            </tr>
            <tr>
                <th>Nom</th>
                <td><?php echo htmlspecialchars($product['name']); ?></td>
            </tr>
            <tr>
                <th>Quantité</th>
                <td><?php echo htmlspecialchars($product['quantity']); ?></td>
            </tr>
            <tr>
                <th>Date de création</th>
                <td><?php echo htmlspecialchars($product['created_at']); ?></td>
            </tr>
        </table>

        <!-- Boutons d'action -->
        <a href="../index.php" class="btn btn-secondary">Retour à la liste des produits</a>
        <!-- Vous pouvez ajouter d'autres actions comme la modification ou la suppression -->
    </div>
</div>

</body>
<?php require_once '../../includes/footer.php'; ?>

</html>
