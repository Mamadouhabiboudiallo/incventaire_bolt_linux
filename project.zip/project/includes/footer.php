</main>
    <footer class="footer">
        <div class="container">
            <p class="text-center text-muted">&copy; <?php echo date('Y'); ?> Inventory Management System</p>
        </div>
    </footer>
</body>
</html>