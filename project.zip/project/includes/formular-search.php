<!-- Formulaire de recherche dans l'en-tête -->
<form action="search.php" method="GET" class="search-form">
    <label for="search_type">Rechercher un :</label>
    <select name="search_type" id="search_type">
        <option value="product">Produit</option>
        <option value="customer">Client</option>
    </select>
    
    <label for="search_query">Terme de recherche :</label>
    <input type="text" name="search_query" id="search_query" required>
    
    <button type="submit" class="btn btn-primary">Rechercher</button>
</form>
